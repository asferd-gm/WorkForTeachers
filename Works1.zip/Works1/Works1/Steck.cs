﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Works1
{
    class Steck<T>
    {
        
        private T[] Mas;
        private int _Size;
        public int Size
        {
            get
            {
                return _Size;
            }
        }
        public Steck()
        {
            _Size = 0;
            Mas = new T[0];
        }

        public Steck(int s)
        {
            _Size = s;
            Mas = new T[s];
        }
        
        public Steck(T[] mas)
        {
            _Size = mas.Length;
            Mas = mas;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Res()
        {
            return (Convert.ToInt32(Mas[0].ToString()) + Convert.ToInt32(Mas[1].ToString())).ToString();
        }
        /// <summary>
        /// Вставляем элемент в конец очереди
        /// </summary>
        /// <param name="_new">Новый элемент для вствки</param>
        public void Append(T _new)
        {
            _Size++;
            Array.Resize(ref Mas, _Size);
            Mas[_Size - 1] = _new;
        }
        /// <summary>
        /// Вставляем массив элементов в конец очереди
        /// </summary>
        /// <param name="_new"></param>
        public void Append(T[] _new)
        {
            //Size+= _new.Length;
            Array.Resize(ref Mas, _Size + _new.Length);
            foreach (T temp in _new)
            {
                Mas[_Size++] = temp;
            }
        }

        public T Pop()
        {
            T temp = Mas[0];
            for (int i = 1; i< Size; i++)
            {
                Mas[i - 1] = Mas[i];
            }
            Array.Resize(ref Mas, --_Size);
            return temp;
        }

        public int _size()
        {
            return _Size;
        }

        //public static T operator +(T a, T b) 
        //{
        //    if(a.GetType() == typeof(int))
        //    {
        //        string v = Convert.ToInt32(a.ToString() + b.ToString()).ToString();
        //        return v;
        //    }
        //    return 0;
        //}
    }
}
