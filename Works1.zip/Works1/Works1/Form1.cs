﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Works1
{
    public partial class Form1 : Form
    {
        Steck<int> m = new Steck<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            m.Append(0);
            m.Append(new int[] { 1, 2, 5 });
            m.Append(new int[] { 1, 2, 5 });
            int temp = m.Pop();
            MessageBox.Show(temp.ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
            openFileDialog1.ShowDialog();
            var input = File.ReadAllText(openFileDialog1.FileName).Split(' ');
            int k = Convert.ToInt32(textBox1.Text);
            int c = 0;
            double min = 0;
            double max = 0;
            min = Convert.ToDouble(input[0]);
            max = Convert.ToDouble(input[0]);
            for (int i = 0; i<input.Length; i++)
            {

                if ((i) % k == 0 && i != 0)
                {
                    richTextBox1.Text = $"{richTextBox1.Text}min = {min}\nmax = {max}\n";
                    min = Convert.ToDouble(input[i]);
                    max = Convert.ToDouble(input[i]);
                    //richTextBox1.Text = richTextBox1.Text + "min = " + min+"\nmax = "+max+"\n";
                    continue;
                }

                if (Convert.ToDouble(input[i]) > max)
                {
                    max = Convert.ToDouble(input[i]);
                }
                if (Convert.ToDouble(input[i]) < min)
                {
                    min = Convert.ToDouble(input[i]);
                }
            }
            richTextBox1.Text = $"{richTextBox1.Text}min = {min}\nmax = {max}\n";

        }
    }
}
